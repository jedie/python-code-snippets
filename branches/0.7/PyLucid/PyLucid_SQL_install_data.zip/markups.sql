CREATE TABLE `$$markups` (  `id` int(11) NOT NULL auto_increment,  `name` varchar(50) NOT NULL default '',  PRIMARY KEY  (`id`)) COMMENT='Liste of available markups (manually created!)';
INSERT INTO `$$markups` VALUES (1,'None'),(2,'textile');
