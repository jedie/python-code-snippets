CREATE TABLE `$$template_engines` (  `id` tinyint(1) NOT NULL auto_increment,  `name` varchar(50) NOT NULL default '',  PRIMARY KEY  (`id`),  UNIQUE KEY `name` (`name`)) COMMENT='Liste of available template engines (manually created!)';
INSERT INTO `$$template_engines` VALUES (1,'None'),(2,'string formatting'),(3,'TAL'),(4,'jinja');
